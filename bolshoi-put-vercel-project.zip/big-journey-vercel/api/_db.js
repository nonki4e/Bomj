const { neon } = require('@neondatabase/serverless');

function db(){
  if(!process.env.DATABASE_URL) throw new Error('DATABASE_URL is not configured');
  return neon(process.env.DATABASE_URL);
}

async function ensureTables(sql){
  await sql`CREATE TABLE IF NOT EXISTS players (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL DEFAULT 'Игрок',
    level INTEGER NOT NULL DEFAULT 1,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`;
  await sql`CREATE TABLE IF NOT EXISTS access_grants (
    id TEXT PRIMARY KEY,
    admin BOOLEAN NOT NULL DEFAULT FALSE,
    player BOOLEAN NOT NULL DEFAULT FALSE,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  )`;
  await sql`INSERT INTO access_grants (id,admin,player)
    VALUES ('P-MVNG3CS5-P96HB',TRUE,TRUE)
    ON CONFLICT (id) DO UPDATE SET admin=TRUE, player=TRUE, updated_at=NOW()`;
}

function cleanId(v){
  return String(v ?? '').trim().toUpperCase().slice(0,80);
}
function json(res,status,data){
  res.status(status).setHeader('Content-Type','application/json; charset=utf-8');
  res.setHeader('Cache-Control','no-store');
  return res.end(JSON.stringify(data));
}
function cors(req,res){
  res.setHeader('Access-Control-Allow-Origin','*');
  res.setHeader('Access-Control-Allow-Headers','Content-Type, X-Owner-Secret');
  res.setHeader('Access-Control-Allow-Methods','GET,POST,OPTIONS');
  if(req.method==='OPTIONS'){res.status(204).end();return true;}
  return false;
}
function ownerAuthorized(req){
  const secret=process.env.OWNER_SECRET;
  if(!secret) return false;
  return String(req.headers['x-owner-secret']||'')===String(secret);
}
module.exports={db,ensureTables,cleanId,json,cors,ownerAuthorized};
