const {db,ensureTables,cleanId,json,cors}=require('./_db');
module.exports=async function handler(req,res){
  if(cors(req,res)) return;
  try{
    const sql=db(); await ensureTables(sql);
    if(req.method==='GET'){
      const q=String(req.query?.q||'').trim().toUpperCase();
      const rows=q
        ? await sql`SELECT id,name,level,updated_at AS "updatedAt" FROM players WHERE UPPER(id) LIKE ${'%'+q+'%'} OR UPPER(name) LIKE ${'%'+q+'%'} ORDER BY updated_at DESC LIMIT 200`
        : await sql`SELECT id,name,level,updated_at AS "updatedAt" FROM players ORDER BY updated_at DESC LIMIT 10000`;
      return json(res,200,{ok:true,players:rows});
    }
    if(req.method==='POST'){
      const id=cleanId(req.body?.id); if(!id) return json(res,400,{ok:false,error:'ID required'});
      const name=String(req.body?.name||'Игрок').trim().slice(0,32)||'Игрок';
      const level=Math.max(1,Math.min(100000,Number(req.body?.level)||1));
      const rows=await sql`INSERT INTO players(id,name,level,updated_at) VALUES(${id},${name},${level},NOW())
        ON CONFLICT(id) DO UPDATE SET name=EXCLUDED.name,level=EXCLUDED.level,updated_at=NOW()
        RETURNING id,name,level,updated_at AS "updatedAt"`;
      return json(res,200,{ok:true,player:rows[0]});
    }
    return json(res,405,{ok:false,error:'Method not allowed'});
  }catch(e){console.error(e);return json(res,500,{ok:false,error:e.message||'Server error'});}
};
