const {db,ensureTables,cleanId,json,cors,ownerAuthorized}=require('./_db');
module.exports=async function handler(req,res){
  if(cors(req,res)) return;
  try{
    const sql=db(); await ensureTables(sql);
    if(req.method==='GET'){
      const id=cleanId(req.query?.id); if(!id)return json(res,400,{ok:false,error:'ID required'});
      const rows=await sql`SELECT id,admin,player,updated_at AS "updatedAt" FROM access_grants WHERE id=${id}`;
      const g=rows[0]||{id,admin:false,player:false};
      if(id==='0') return json(res,200,{ok:true,access:{admin:true,player:true,owner:true}});
      return json(res,200,{ok:true,access:{admin:!!g.admin,player:!!g.player,owner:false}});
    }
    if(req.method==='POST'){
      if(!ownerAuthorized(req)) return json(res,403,{ok:false,error:'Owner secret required'});
      const id=cleanId(req.body?.id); if(!id)return json(res,400,{ok:false,error:'ID required'});
      if(id==='0') return json(res,400,{ok:false,error:'ID 0 always has all access'});
      const admin=!!req.body?.admin, player=!!req.body?.player;
      const rows=await sql`INSERT INTO access_grants(id,admin,player,updated_at) VALUES(${id},${admin},${player},NOW())
        ON CONFLICT(id) DO UPDATE SET admin=${admin},player=${player},updated_at=NOW()
        RETURNING id,admin,player,updated_at AS "updatedAt"`;
      return json(res,200,{ok:true,access:{admin:!!rows[0].admin,player:!!rows[0].player,owner:false}});
    }
    return json(res,405,{ok:false,error:'Method not allowed'});
  }catch(e){console.error(e);return json(res,500,{ok:false,error:e.message||'Server error'});}
};
