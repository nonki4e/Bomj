const {db,ensureTables,json,cors}=require('./_db');
module.exports=async function handler(req,res){
  if(cors(req,res)) return;
  try{const sql=db();await ensureTables(sql);return json(res,200,{ok:true,service:'Большой путь API',time:new Date().toISOString()});}
  catch(e){return json(res,500,{ok:false,error:e.message||'Database error'});}
};
